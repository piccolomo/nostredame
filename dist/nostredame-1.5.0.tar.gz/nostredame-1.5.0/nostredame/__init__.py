from .globals import read_data
from .file import read_text
